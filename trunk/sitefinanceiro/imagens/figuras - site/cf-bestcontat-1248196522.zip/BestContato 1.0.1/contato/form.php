<?
session_start();

/******************************************************
**
**	Nome do Arquivo: form.php
**	Data de Cria��o: 01/05/2007
**	Autor: Thiago Felipe Festa - thiagofesta@gmail.com
**	�ltima altera��o:
**	Modificado por:
**
******************************************************/

// Inicio a sess�o, pois estamos trabalhando com sess�es.

// Aqui � a a��o do formul�rio, se clicar em enviar ele chama isto.
if( $_GET["validar"] == "form" ){

	// Texto digitado no campo imagem, e transformando tudo em m�n�sculo, caso queria que haja distin��o de mai�sculas e min�sculas, s� retire o strtoupper().
 	$txtImagem = strtoupper($_POST["txtImagem"]);
	
	// Caracteres que est�o na imagem, tamb�m deixando tudo em min�sulo.
	$valorImagem = strtoupper($_SESSION["autenticaIMG"]);
	
	// Verificando se o texto digitado, for igual aos caracteres que est�o na imagem
	if( $txtImagem == $valorImagem ){
		echo "->";

        include ("enviar.php"); /* Se os dados est�o corretos ent�o enviar� o e-mail com os formul�rio abaixo
                                   N�o esque�a de Configurar o Enviar.php */


    } else {
		echo "Desculpa ". $_POST["Nome"] .", os caracteres digitados est�o incorretos!";
	}

}

// Incluindo o imgSet.php que seta os valores da sess�o.
require_once ("imgSet.php");	

?>
<!--
Notem que ali no <img src="imgGera.php">, eu chamo o arquivo imgGera.php...
estou adicionando ele, pois nele que est� inst�nciada a classe imagem
-->

<!-- O Formulario foi desenvolvido utilizando no sistema de Captcha acima, por Arthur Bonora
www.arthurbonora.com.br
-->

<html>
<head>
<style type="text/css">
<!--
.Estilo3 {font-family: Geneva, Arial, Helvetica, sans-serif; font-size: 12; }
.Estilo4 {font-size: 12}
.Estilo5 {
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.Estilo10 {
	font-size: 9px;
	color: #333333;
}
.Estilo13 {
	font-size: 7px;
	color: #333333;
	font-family: Geneva, Arial, Helvetica, sans-serif;
}
-->
</style>
</head>
<body>

<form id="form1" name="frmImgValida" method="post" action="form.php?validar=form">
  <table width="30%" border="0" cellspacing="2">
    <tr>
      <td width="12%" class="Estilo5"><p class="Estilo3">Nome:</p></td>
      <td width="88%"><span class="Estilo4">
        <label>
        <input name="Nome" type="text" id="Nome" size="40" />
        </label>
      </span></td>
    </tr>
    <tr>
      <td class="Estilo5"><span class="Estilo3">E-mail:</span></td>
      <td><span class="Estilo4">
        <input name="email" type="text" id="email" size="40" />
      </span></td>
    </tr>
    <tr>
      <td class="Estilo5"><span class="Estilo3">Fone:</span></td>
      <td><span class="Estilo4">
        <input name="fone" type="text" id="fone" size="20" />
      </span></td>
    </tr>
    <tr>
      <td class="Estilo5"><p class="Estilo3">Assunto:</p>
      </td>
      <td><label><span class="Estilo4">
      <input name="assunto" type="text" id="assunto" size="27" />
      </span></label></td>
    </tr>
    <tr>
      <td class="Estilo5"><p class="Estilo3">Mensagem:</p>
      <p class="Estilo3">&nbsp;</p>
      <p class="Estilo3">&nbsp;</p>
      <p class="Estilo3">&nbsp;</p>
      <p class="Estilo3">&nbsp;</p>
      <p class="Estilo3">&nbsp;</p>
      </td>
      <td><span class="Estilo4">
        <textarea name="mensagem" cols="40" rows="10" id="mensagem"></textarea>
      </span></td>
    </tr>
    <tr>
      <td class="Estilo5"><p class="Estilo5">&nbsp;</p>
      <p class="Estilo5">&Eacute; Voc&ecirc;? </p></td>
      <td><span class="Estilo4">
        <label>
        <input name="txtImagem" type="text" id="txtImagem" size="20" />
        </label>
      </span>
	  <img src="imgGera.php">
	  </td>
    </tr>
    <tr>
      <td><span class="Estilo4"></span></td>
      <td><div align="right"><span class="Estilo4">
      </span></div>        <span class="Estilo4"><label>
        </span>
      <div align="right"> <span class="Estilo10">
        <input type="submit" name="Submit" value="Enviar" />
      </span></div>
      <span class="Estilo10">
        </label>
        </span><span class="Estilo13"><a href="http://www.arthurbonora.com.br" target="_blank">Best Contato 1.0.1</a></span> </td>
    </tr>
  </table>
</form>

</body>
</html>

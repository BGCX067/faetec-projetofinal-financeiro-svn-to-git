<?
$hoje_tmp = getdate();
$hoje = ($hoje_tmp[hours].":".$hoje_tmp[minutes].":".$hoje_tmp[seconds]);

$nome = $_POST["Nome"];
$email = $_POST["email"];
$fone = $_POST["fone"];
$assunto = $_POST["assunto"];
$mensagem = $_POST["mensagem"];


global $email;

// FA�A ESTAS CONFIGURA��ES

$enviou = mail("xxxxxxx@xxxxxxx.xxxx", // COLOQUE SEU E-MAIL AQUI!
"xxxxxxxx Assunto xxxxxxxxxxx", // COLOQUE O ASSUNTO DO E-MAIL A SER RECEBIDO

// TERMINO DA CONFIGURA��O

"Nome: $nome
 E-mail: $email
 Fone: $fone
 Assunto: $assunto
 Mensagem: $mensagem
======================"
,
"From: $nome <$nome>");

if ($enviou){
echo "<b>$nome</b>, Contato Enviado com Sucesso! Aguarde nosso retorno!.";
}

else {
echo "<b>$nome</b>, N�o enviado<br>Tente novamente.";
}
?>
